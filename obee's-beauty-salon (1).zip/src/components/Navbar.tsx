import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    { name: "Home", path: "/" },
    { name: "Services & Rates", path: "/rates" },
    { name: "Gallery", path: "/gallery" },
    { name: "Appointment", path: "/appointment" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#F8F5F0]/90 backdrop-blur-md border-b border-[#E8E0D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" className="flex items-center">
            <span className="font-serif text-3xl font-semibold tracking-wide text-[#332D29]">Obee's</span>
            <span className="font-sans text-xs uppercase tracking-[0.2em] ml-3 text-[#7A6B63] mt-2 hidden sm:block">Beauty Salon</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex space-x-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-sans text-sm uppercase tracking-wider transition-colors hover:text-[#A68A7C] ${
                  location.pathname === link.path ? "text-[#A68A7C] font-medium" : "text-[#7A6B63]"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-[#7A6B63] hover:text-[#332D29] focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-[#F8F5F0] border-b border-[#E8E0D5] absolute w-full">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block px-3 py-2 rounded-md font-sans text-sm uppercase tracking-wider ${
                  location.pathname === link.path
                    ? "text-[#A68A7C] font-medium bg-[#E8E0D5]/30"
                    : "text-[#7A6B63] hover:bg-[#E8E0D5]/20 hover:text-[#332D29]"
                }`}
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
