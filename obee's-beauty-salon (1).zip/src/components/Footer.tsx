import { Instagram, MapPin, Phone, Clock } from "lucide-react";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-[#332D29] text-[#F8F5F0] py-16 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center md:text-left">
          
          <div className="flex flex-col items-center md:items-start">
            <h3 className="font-serif text-3xl font-medium mb-4">Obee's</h3>
            <p className="font-sans text-sm uppercase tracking-widest text-[#BDB1A6] mb-6">Beauty Salon</p>
            <p className="font-sans text-sm text-[#BDB1A6] max-w-xs leading-relaxed">
              Experience elegance and professional care in a relaxing environment.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-start font-sans text-sm text-[#BDB1A6] space-y-4">
            <h4 className="uppercase tracking-[0.15em] text-[#F8F5F0] font-medium mb-2">Contact Us</h4>
            <a href="https://maps.google.com/?q=House+No+8,+Main+Tulsa+Rd,+Lalazar,+Rawalpindi,+48000,+Pakistan" target="_blank" rel="noreferrer" className="flex items-start gap-3 hover:text-white transition-colors text-left">
              <MapPin size={18} className="shrink-0 mt-0.5" />
              <span>House No 8, Main Tulsa Rd,<br/>Lalazar, Rawalpindi, 48000,<br/>Pakistan</span>
            </a>
            <a href="tel:03150055330" className="flex items-center gap-3 hover:text-white transition-colors">
              <Phone size={18} />
              <span>0315 0055330</span>
            </a>
            <a href="https://www.instagram.com/obees.official/" target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:text-white transition-colors">
              <Instagram size={18} />
              <span>@obees.official</span>
            </a>
          </div>

          <div className="flex flex-col items-center md:items-start font-sans text-sm text-[#BDB1A6] space-y-3">
             <h4 className="uppercase tracking-[0.15em] text-[#F8F5F0] font-medium mb-2">Timings</h4>
             <div className="flex items-start gap-3 flex-col">
               <div className="flex items-center gap-2 text-[#BDB1A6]">
                 <Clock size={16} />
                 <span>Sun - Sat: 10:30 AM – 8:00 PM</span>
               </div>
               <Link to="/appointment" className="mt-4 inline-block border border-[#A68A7C] text-[#A68A7C] hover:bg-[#A68A7C] hover:text-[#332D29] transition-colors py-2 px-6 rounded-full text-xs uppercase tracking-widest">
                 Book Appointment
               </Link>
             </div>
          </div>
          
        </div>
        
        <div className="border-t border-[#4A423C] mt-16 pt-8 text-center text-xs font-sans text-[#7A6B63]">
          &copy; {new Date().getFullYear()} Obee's Beauty Salon. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
