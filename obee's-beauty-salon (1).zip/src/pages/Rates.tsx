export function Rates() {
  const rateCategories = [
    {
      name: "Hair Cuts & Styles",
      items: [
        { name: "Blow dry (short length)", price: "2000" },
        { name: "Blow dry (mid/long length)", price: "2500–3500" },
        { name: "Roller setting", price: "3000" },
        { name: "Straightening (short length)", price: "1500" },
        { name: "Straightening (mid-long)", price: "2000–3000" },
        { name: "Curls (short length)", price: "2000" },
        { name: "Curls (Mid-Long)", price: "2500–4000" },
        { name: "Back combing", price: "1000–1500" },
        { name: "Jurra/buns/up-do's", price: "Varies" },
        { name: "Braids", price: "1500–4000" },
        { name: "Bridal hairstyle", price: "4000–6000" },
        { name: "Wash with conditioner", price: "600" },
        { name: "Wash with conditioner & paddle dry", price: "1000" },
        { name: "Protein Wash", price: "1000" },
        { name: "Keratin Wash", price: "1000" },
        { name: "Purple Shampoo Wash", price: "1000" },
        { name: "Child's Trim", price: "800–1000" },
        { name: "Child's haircut", price: "1200–1500" },
        { name: "Trimming (without blow dry)", price: "1500–2500" },
        { name: "Haircut with blow dry (mid/long length)", price: "3500–4500" },
        { name: "Haircut with blow dry (short length)", price: "2500" },
        { name: "Flick/fringe/bangs", price: "500" },
      ]
    },
    {
      name: "Hair Dye",
      items: [
        { name: "Root touch (half inch-one inch)", price: "3000" },
        { name: "Root touch L'Oreal majirel (Half-one inch)", price: "4000" },
        { name: "Root touch with glossing", price: "6000–8000" },
        { name: "Full hair dye short length", price: "6000–8000" },
        { name: "Full hair dye short (L'oreal majirel)", price: "10,000–15,000" },
        { name: "Full hair dye mid length", price: "8000–12000" },
        { name: "Full hair dye long length", price: "12000–18000" },
        { name: "Full hair dye long length (L'Oréal majirel)", price: "15000–25000" },
        { name: "Hair Glossing", price: "5000–8000" },
        { name: "Add on bond fusion", price: "2000–3000" },
        { name: "Root touch application (client's own dye)", price: "800" },
        { name: "Full hair dye application (client's own dye)", price: "1500–2000" },
      ],
      note: "*Prices for hair dye vary according to hair length and volume"
    },
    {
      name: "Keratin & Hair Treatments",
      items: [
        { name: "Keratin (shoulder length)", price: "12,000–15,000" },
        { name: "Keratin (armpit length)", price: "15,000–18,000" },
        { name: "Keratin (mid back length)", price: "18,000–25,000" },
        { name: "Keratin (hip length)", price: "25,000–35,000" },
        { name: "Hot oil treatment with wash", price: "3000" },
        { name: "Bremod hair treatment", price: "3500–4500" },
        { name: "Treatment for damaged hair", price: "3500–5000" },
        { name: "L'Oreal hair treatment", price: "3500–6000" },
        { name: "Bond fusion for extreme damaged hair", price: "3500–5000" },
        { name: "Dandruff Treatment", price: "3500–5000" },
        { name: "Scalp detox hair treatment", price: "5000–7000" },
      ],
      note: "*All our hair treatments come with a relaxing and rejuvenating head and neck massage."
    },
    {
      name: "Nano Plastia",
      items: [
        { name: "Shoulder length", price: "15,000–18,000" },
        { name: "Armpit length", price: "22,000–25,000" },
        { name: "Mid-back length", price: "25,000–35,000" },
        { name: "Hip length", price: "35,000–45,000" },
      ],
      note: "*Price varies according to the hair length & thickness. Extra charges for thick/dense hair."
    },
    {
      name: "Facial & Skincare",
      items: [
        { name: "Basic glow facial", price: "1800" },
        { name: "Basic whitening facial (with polishing)", price: "2500" },
        { name: "Organic Cleansing", price: "2000" },
        { name: "Organic facial", price: "3000" },
        { name: "Organic whitening facial (with polishing)", price: "3500" },
        { name: "Organic face polish", price: "2000" },
        { name: "Derma cleansing", price: "2500" },
        { name: "Derma facial", price: "3000" },
        { name: "Derma whitening facial (with polishing)", price: "3500" },
        { name: "Brightening skin rejuvenating facial", price: "4000" },
        { name: "High frequency facial", price: "8000" },
        { name: "Co-natural whitening facial (with polishing)", price: "6500" },
        { name: "Conatural brightening facial", price: "6000" },
      ],
      note: "*All our facials come with a relaxing and rejuvenating face, neck and shoulder massage."
    },
    {
      name: "Fruit Wax",
      items: [
        { name: "Full Body Wax", price: "7000" },
        { name: "Under arms", price: "600" },
        { name: "Full arms", price: "1500" },
        { name: "Half arms", price: "1000" },
        { name: "Full legs", price: "1800" },
        { name: "Half legs", price: "1000" },
        { name: "Stomach", price: "1500" },
        { name: "Back", price: "1500" },
        { name: "Hips", price: "1500" },
        { name: "Chest", price: "1200" },
        { name: "Hand/Feet", price: "1200" },
      ]
    },
    {
      name: "Hot Wax",
      items: [
        { name: "Full face (including eyebrows)", price: "1500" },
        { name: "Full face and neck", price: "2000" },
        { name: "Forehead", price: "500" },
        { name: "Eyebrows", price: "500" },
        { name: "Upper lips", price: "400" },
        { name: "Chin and side burns", price: "800" },
      ]
    },
    {
      name: "Threading",
      items: [
        { name: "Eyebrows", price: "200" },
        { name: "Upper lips", price: "100" },
        { name: "Forehead", price: "400" },
        { name: "Full face", price: "1500" },
        { name: "Full face with neck", price: "1800" },
      ]
    },
    {
      name: "Massage",
      items: [
        { name: "Hand massage (15 mins)", price: "1200" },
        { name: "Foot massage (15 mins)", price: "1200" },
        { name: "Face & neck massage (15 mins)", price: "1500" },
        { name: "Arms / Legs / Back massage (25 mins)", price: "2000" },
        { name: "Head & shoulder massage (15 mins)", price: "2000" },
        { name: "Full body hot oil massage (1 hour)", price: "5000" },
        { name: "Full body scrubbing with steam (1 hour)", price: "5000" },
        { name: "Hot stone massage (1:15 hour)", price: "8000" },
      ]
    },
    {
      name: "Nails",
      items: [
        { name: "Transparent full nails with nail paint", price: "2500" },
        { name: "French tips with gel shine", price: "3500" },
        { name: "Transparent nails with gel polish (one color)", price: "4000" },
        { name: "Transparent nails with gel polish french", price: "4500" },
        { name: "Transparent nails with chrome powder", price: "5000" },
        { name: "Gel polish on own nails (over lay)", price: "2500" },
        { name: "Gel polish on own nails french (over lay)", price: "3000–3500" },
      ]
    },
    {
      name: "Makeup",
      items: [
        { name: "Bridal makeup, first day with service", price: "45000" },
        { name: "Walima make up", price: "40000" },
        { name: "Mehndi makeup", price: "25000" },
        { name: "Engagement makeup", price: "25000" },
        { name: "Nikkah makeup", price: "25000" },
        { name: "Signature party makeup by Zaynah Khan", price: "12000" },
        { name: "Light party makeup", price: "7000" },
        { name: "Heavy party makeup", price: "9000" },
        { name: "Eye makeup with lashes", price: "3500" },
        { name: "Lash application with liner & mascara", price: "800" },
        { name: "Bridal mehndi", price: "8000–10000" },
      ]
    },
    {
      name: "Eye Lash Extensions",
      items: [
        { name: "Classic lash set", price: "8000" },
        { name: "Classic wet look", price: "9000" },
        { name: "Hybrid lash set", price: "10000" },
        { name: "Volume lash set", price: "12000" },
        { name: "Mega Volume", price: "13000" },
        { name: "Refill charges for classic", price: "4000" },
        { name: "Eyebrow tinting", price: "2000–2500" },
      ]
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-20">
      <div className="text-center mb-16">
        <h1 className="font-serif text-5xl md:text-6xl text-[#332D29] mb-4">Services & Rates</h1>
        <p className="font-sans text-sm uppercase tracking-widest text-[#A68A7C]">Discover Our Pricing</p>
        <div className="w-12 h-px bg-[#A68A7C] mx-auto mt-8"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
        {rateCategories.map((category, idx) => (
          <div key={idx} className="bg-white p-8 rounded-3xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-[#E8E0D5]">
            <h2 className="font-serif text-3xl text-[#332D29] mb-6 border-b border-[#E8E0D5] pb-4">{category.name}</h2>
            <div className="space-y-4">
              {category.items.map((item, i) => (
                <div key={i} className="flex justify-between items-baseline font-sans">
                  <span className="text-[#524842] pr-4">{item.name}</span>
                  <div className="flex-grow border-b border-dotted border-[#BDB1A6] mx-2 opacity-50 relative top-[-4px]"></div>
                  <span className="text-[#332D29] font-medium whitespace-nowrap pl-2">Rs. {item.price}</span>
                </div>
              ))}
            </div>
            {category.note && (
              <p className="mt-6 text-xs text-[#A68A7C] font-sans italic opacity-80">{category.note}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
