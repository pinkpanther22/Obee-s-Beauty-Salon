import { Link } from "react-router-dom";

export function Home() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-80px)]">
      {/* Hero Section */}
      <section className="flex-grow flex items-center justify-center py-20 px-4 relative overflow-hidden">
        {/* Abstract background element */}
        <div className="absolute inset-0 z-0 opacity-20 bg-[radial-gradient(circle_at_70%_30%,_#E8E0D5_0%,_transparent_60%)]"></div>
        
        <div className="text-center z-10 max-w-4xl mx-auto space-y-8 -mt-8 md:-mt-16">
          
          <div className="mx-auto w-full max-w-2xl mb-8 rounded-2xl overflow-hidden shadow-2xl border border-[#E8E0D5]">
            <img 
              src="https://other-pink-yfixd4dajj.edgeone.app/elegant-salon-sign-design-for-obees-beauty-salon-l.jpeg" 
              alt="Obee's Beauty Salon Signboard"
              className="w-full h-auto object-cover aspect-[16/9] bg-[#E8E0D5]"
              onError={(e) => {
                 (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?q=80&w=2069&auto=format&fit=crop';
              }}
            />
          </div>

          <p className="font-sans text-[#7A6B63] max-w-xl mx-auto leading-relaxed mt-6">
            Redefining elegance with expert care. Discover our range of premium beauty services in a relaxing, luxurious environment tailored just for you.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10">
            <Link 
              to="/appointment"
              className="bg-[#332D29] text-[#F8F5F0] py-4 px-8 rounded-full font-sans uppercase tracking-widest text-xs hover:bg-[#4A423C] transition-colors"
            >
              Book an Appointment
            </Link>
            <Link 
              to="/rates"
              className="bg-transparent border border-[#332D29] text-[#332D29] py-4 px-8 rounded-full font-sans uppercase tracking-widest text-xs hover:bg-[#E8E0D5] transition-colors"
            >
              View Services
            </Link>
          </div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-20 bg-[#F2ECE4]">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="font-serif text-4xl mb-6">Our Philosophy</h2>
          <div className="w-16 h-px bg-[#A68A7C] mx-auto mb-8"></div>
          <p className="font-sans text-[#7A6B63] leading-loose max-w-2xl mx-auto">
            At Obee's, we believe beauty is an art and a science. We use top-tier products and tailored techniques to bring out your natural glow. Our dedicated professionals ensure every visit leaves you feeling rejuvenated and confident.
          </p>
        </div>
      </section>
    </div>
  );
}
