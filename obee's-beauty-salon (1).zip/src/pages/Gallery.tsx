export function Gallery() {
  const items = [
    { title: "Salon Interior", image: "https://ltd-tomato-dqixhekmy8.edgeone.app/658337560_4408510822738296_1600590755297370586_n.jpg" },
    { title: "Hair Styling", image: "https://primitive-silver-uvrkl9expq.edgeone.app/685118744_2092200001643401_4392559022660579749_n.jpg" },
    { title: "Nail Art", image: "https://tense-aqua-pjxzl3gfgg.edgeone.app/688584733_1337527418296953_1586620091900264322_n.jpg" },
    { title: "Bridal Makeup", image: "https://willing-coffee-ym8xwdofvw.edgeone.app/678933396_1664068101476006_7788747250142787604_n.jpg" },
    { title: "Facial Treatment", image: "https://severe-amethyst-oyhxlqeupp.edgeone.app/681053080_2167718770693456_2026715175247254152_n.jpg" },
    { title: "Relaxing Massage", image: "https://boiling-turquoise-ajo6ongxi8.edgeone.app/679180792_3211201052578315_5996430938725117019_n.jpg" },
    { title: "Manicure Setup", image: "https://tasteless-plum-mo0pgcgoy4.edgeone.app/685655681_1874397116601326_8514963218220223069_n.jpg" },
    { title: "Premium Products", image: "https://relieved-maroon-jptktbd2z0.edgeone.app/683633732_2183810732448014_5453523835171561450_n%20(1).jpg" },
    { title: "Happy Client", image: "https://plain-crimson-quxppvazag.edgeone.app/680267605_1589873342108377_5351603474472747869_n.jpg" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-20">
      <div className="text-center mb-16">
        <h1 className="font-serif text-5xl md:text-6xl text-[#332D29] mb-4">Gallery</h1>
        <p className="font-sans text-sm uppercase tracking-widest text-[#A68A7C]">Inside Obee's Beauty Salon</p>
        <div className="w-12 h-px bg-[#A68A7C] mx-auto mt-8"></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item, index) => (
          <div 
            key={index}
            className="aspect-square bg-[#E8E0D5] flex items-center justify-center rounded-2xl transition-all duration-300 hover:bg-[#D5C9B8] overflow-hidden relative"
          >
            {item.image ? (
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-6 border border-[#BDB1A6] rounded-xl flex items-center justify-center p-4">
                <span className="font-serif text-2xl text-[#7A6B63] italic opacity-60 text-center">
                  {item.title}
                </span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
