import { useState } from "react";

export function Appointment() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate booking
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-20">
      <div className="text-center mb-16">
        <h1 className="font-serif text-5xl md:text-6xl text-[#332D29] mb-4">Book Appointment</h1>
        <p className="font-sans text-sm uppercase tracking-widest text-[#A68A7C]">Reserve Your Spot</p>
        <div className="w-12 h-px bg-[#A68A7C] mx-auto mt-8"></div>
      </div>

      {submitted ? (
        <div className="bg-[#E8E0D5] rounded-3xl p-12 text-center">
          <h2 className="font-serif text-3xl text-[#332D29] mb-4">Request Sent!</h2>
          <p className="font-sans text-[#7A6B63]">
            Thank you for booking with Obee's. We will contact you shortly to confirm your appointment.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-[0_8px_30px_rgba(0,0,0,0.04)]">
          <form onSubmit={handleSubmit} className="space-y-6 flex flex-col font-sans">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-xs uppercase tracking-wider text-[#7A6B63] mb-2">Full Name</label>
                <input 
                  type="text" 
                  id="name" 
                  required
                  className="w-full bg-[#F8F5F0] border-none rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#A68A7C] text-[#332D29]"
                  placeholder="e.g. Jane Doe"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-xs uppercase tracking-wider text-[#7A6B63] mb-2">Phone Number</label>
                <input 
                  type="tel" 
                  id="phone" 
                  required
                  className="w-full bg-[#F8F5F0] border-none rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#A68A7C] text-[#332D29]"
                  placeholder="0315 0055330"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="service" className="block text-xs uppercase tracking-wider text-[#7A6B63] mb-2">Service Required</label>
                <select 
                  id="service" 
                  required
                  className="w-full bg-[#F8F5F0] border-none rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#A68A7C] text-[#332D29] apperance-none"
                >
                  <option value="">Select a service...</option>
                  <option value="Hair Cut / Style">Hair Cut & Style</option>
                  <option value="Hair Dye / Treatment">Hair Dye & Treatments</option>
                  <option value="Facial">Facial & Skincare</option>
                  <option value="Massage">Massage</option>
                  <option value="Nails">Nail Services</option>
                  <option value="Waxing">Waxing</option>
                  <option value="Makeup">Makeup (Bridal/Party)</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label htmlFor="date" className="block text-xs uppercase tracking-wider text-[#7A6B63] mb-2">Preferred Date</label>
                <input 
                  type="date" 
                  id="date" 
                  required
                  className="w-full bg-[#F8F5F0] border-none rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#A68A7C] text-[#332D29]"
                />
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-xs uppercase tracking-wider text-[#7A6B63] mb-2">Message (Optional)</label>
              <textarea 
                id="message" 
                rows={4}
                className="w-full bg-[#F8F5F0] border-none rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#A68A7C] text-[#332D29] resize-none"
                placeholder="Any special requests or details?"
              ></textarea>
            </div>

            <button 
              type="submit"
              className="mt-4 w-full bg-[#332D29] text-[#F8F5F0] py-4 rounded-xl font-sans uppercase tracking-widest text-xs hover:bg-[#4A423C] transition-colors"
            >
              Confirm Booking Request
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
