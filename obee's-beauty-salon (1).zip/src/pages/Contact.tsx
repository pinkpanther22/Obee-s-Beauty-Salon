import { MapPin, Phone, Instagram, Clock } from "react-router-dom";
import { MapPin as MapPinIcon, Phone as PhoneIcon, Instagram as InstagramIcon, Clock as ClockIcon } from "lucide-react";

export function Contact() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-20">
      <div className="text-center mb-16">
        <h1 className="font-serif text-5xl md:text-6xl text-[#332D29] mb-4">Contact Us</h1>
        <p className="font-sans text-sm uppercase tracking-widest text-[#A68A7C]">Get in touch with Obee's</p>
        <div className="w-12 h-px bg-[#A68A7C] mx-auto mt-8"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        <div className="bg-[#F2ECE4] p-10 rounded-3xl">
          <h2 className="font-serif text-3xl mb-8">Visit Us</h2>
          
          <div className="space-y-8 font-sans text-[#524842]">
            <div className="flex gap-4">
              <MapPinIcon className="shrink-0 text-[#A68A7C]" />
              <div>
                <p className="font-medium text-[#332D29] mb-1 uppercase tracking-wider text-sm">Address</p>
                <p className="leading-relaxed">House No 8, Main Tulsa Rd,<br/>Lalazar, Rawalpindi, 48000,<br/>Pakistan</p>
              </div>
            </div>

            <div className="flex gap-4">
              <PhoneIcon className="shrink-0 text-[#A68A7C]" />
              <div>
                <p className="font-medium text-[#332D29] mb-1 uppercase tracking-wider text-sm">Phone</p>
                <a href="tel:03150055330" className="hover:text-[#A68A7C] transition-colors">0315 0055330</a>
              </div>
            </div>

            <div className="flex gap-4">
              <InstagramIcon className="shrink-0 text-[#A68A7C]" />
              <div>
                <p className="font-medium text-[#332D29] mb-1 uppercase tracking-wider text-sm">Instagram</p>
                <a href="https://www.instagram.com/obees.official/" target="_blank" rel="noreferrer" className="hover:text-[#A68A7C] transition-colors">
                  @obees.official
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#332D29] text-[#F8F5F0] p-10 rounded-3xl">
          <h2 className="font-serif text-3xl mb-8 text-white">Opening Hours</h2>
          
          <div className="space-y-6 font-sans text-[#BDB1A6]">
            {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((day) => (
              <div key={day} className="flex justify-between items-center border-b border-[#4A423C] pb-4">
                <span className="uppercase tracking-wider text-sm">{day}</span>
                <span>10:30 AM – 8:00 PM</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
